document.getElementById('cpf').addEventListener('input', function() {
    var cpfInput = this;
    var cpf = cpfInput.value.replace(/\D/g, ''); // Remover caracteres não numéricos
    if (cpf.length <= 3) {
        cpfInput.value = cpf;
    } else if (cpf.length <= 6) {
        cpfInput.value = cpf.substring(0, 3) + '.' + cpf.substring(3);
    } else if (cpf.length <= 9) {
        cpfInput.value = cpf.substring(0, 3) + '.' + cpf.substring(3, 6) + '.' + cpf.substring(6);
    } else {
        cpfInput.value = cpf.substring(0, 3) + '.' + cpf.substring(3, 6) + '.' + cpf.substring(6, 9) + '-' + cpf.substring(9);
    }
});
function validarform() {
    function validarform() {
        document.getElementById('form').addEventListener('submit', function(event) {
            event.preventDefault();  // Impede o envio padrão do formulário
            validarform();
        });
        function validarform() {
            // Validação de CPF
            var cpfInput = document.getElementById('cpf');
            var cpf = cpfInput.value.replace(/\D/g, ''); // Remover caracteres não numéricos
            if (cpf.length !== 11) {
                alert('CPF inválido. Deve conter 11 dígitos.');
                return;
            }
            var soma = 0;
            var resto;
            for (var i = 1; i <= 9; i++) {
                soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
            }
            resto = (soma * 10) % 11;
            if (resto === 10 || resto === 11) {
                resto = 0;
            }
            if (resto !== parseInt(cpf.substring(9, 10))) {
                alert('CPF inválido.');
                return;
            }
            soma = 0;
            for (var i = 1; i <= 10; i++) {
                soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
            }
            resto = (soma * 10) % 11;
            if (resto === 10 || resto === 11) {
                resto = 0;
            }
            if (resto !== parseInt(cpf.substring(10, 11))) {
                alert('CPF inválido.');
                return;
            }
            document.getElementById('form').reset();
        }
    }
} 